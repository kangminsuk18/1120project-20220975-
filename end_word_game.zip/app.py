from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# 끝말잇기 단어 목록
word_list = [
    "사과", "과일", "일기", "기차", "차례", "례복", "복지", "지구", "구름", "름새", "새벽",
    "벽돌", "돌멩이", "이상", "상자", "자전거", "거울", "울타리", "리본", "본능"
]

used_words = []

def get_last_char(word):
    return word[-1]

def chatbot_response(user_word):
    if user_word in used_words:
        return "그 단어는 이미 사용된 단어입니다. 다른 단어를 입력해주세요."
    
    last_char = get_last_char(user_word)
    possible_words = [word for word in word_list if word[0] == last_char]
    
    if not possible_words:
        return "더 이상 단어가 없습니다. 게임을 종료합니다!"
    
    response_word = random.choice(possible_words)
    used_words.append(user_word)
    used_words.append(response_word)
    
    return response_word

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/play', methods=['POST'])
def play():
    user_word = request.json['word']
    response_word = chatbot_response(user_word)
    return jsonify({'response': response_word})

if __name__ == '__main__':
    app.run(debug=True)
